#!/bin/bash
cd /home/ubuntu/logivault-ai
echo "🤖 Starting Autonomous Self-Healer..."
echo "Press Ctrl+C to stop"
python3 auto-resolver/autonomous_self_healer.py --autonomous
