#!/bin/bash
cd /home/ubuntu/logivault-ai
python3 auto-resolver/autonomous_self_healer.py
